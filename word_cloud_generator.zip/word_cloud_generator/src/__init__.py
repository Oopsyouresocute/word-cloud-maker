"""
词云生成器主包
"""
from .wordcloud_generator import WordCloudGenerator

__version__ = '1.0.0'
__author__ = 'Your Name'

__all__ = ['WordCloudGenerator'] 