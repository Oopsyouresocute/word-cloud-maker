"""
词云生成器UI包
"""
from .main_window import MainWindow

__all__ = ['MainWindow'] 