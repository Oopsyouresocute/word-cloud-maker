from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                           QPushButton, QLabel, QFileDialog, QTextEdit, QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from pathlib import Path
from ..wordcloud_generator import WordCloudGenerator

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.generator = WordCloudGenerator()
        self.setup_ui()
        
    def setup_ui(self):
        self.setWindowTitle("词云生成器")
        self.setMinimumSize(800, 600)
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        layout = QVBoxLayout(central_widget)
        
        # 文本编辑区
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("在此输入文本或从文件导入...")
        layout.addWidget(self.text_edit)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        
        self.import_btn = QPushButton("导入文本文件")
        self.import_btn.clicked.connect(self.import_text)
        
        self.generate_btn = QPushButton("生成词云")
        self.generate_btn.clicked.connect(self.generate_wordcloud)
        
        self.save_btn = QPushButton("保存词云图片")
        self.save_btn.clicked.connect(self.save_wordcloud)
        
        button_layout.addWidget(self.import_btn)
        button_layout.addWidget(self.generate_btn)
        button_layout.addWidget(self.save_btn)
        
        layout.addLayout(button_layout)
        
        # 预览区域
        self.preview_label = QLabel()
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setMinimumHeight(300)
        self.preview_label.setStyleSheet("QLabel { background-color: white; border: 1px solid #CCCCCC; }")
        layout.addWidget(self.preview_label)
        
    def import_text(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择文本文件",
            "",
            "Text Files (*.txt);;All Files (*)"
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.text_edit.setText(f.read())
            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法读取文件：{str(e)}")
                
    def generate_wordcloud(self):
        text = self.text_edit.toPlainText()
        if not text.strip():
            QMessageBox.warning(self, "警告", "请先输入或导入文本！")
            return
            
        temp_path = str(Path.home() / "temp_wordcloud.png")
        success, message = self.generator.generate(text, temp_path)
        
        if success:
            pixmap = QPixmap(temp_path)
            scaled_pixmap = pixmap.scaled(
                self.preview_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.preview_label.setPixmap(scaled_pixmap)
        else:
            QMessageBox.critical(self, "错误", message)
            
    def save_wordcloud(self):
        if self.preview_label.pixmap() is None:
            QMessageBox.warning(self, "警告", "请先生成词云！")
            return
            
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "保存词云图片",
            "",
            "PNG Files (*.png);;All Files (*)"
        )
        
        if file_path:
            success, message = self.generator.generate(
                self.text_edit.toPlainText(),
                file_path
            )
            
            if success:
                QMessageBox.information(self, "成功", "词云图片已保存！")
            else:
                QMessageBox.critical(self, "错误", message)
    
    def resizeEvent(self, event):
        """窗口大小改变时重新调整预览图片大小"""
        super().resizeEvent(event)
        if self.preview_label.pixmap() is not None:
            scaled_pixmap = self.preview_label.pixmap().scaled(
                self.preview_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.preview_label.setPixmap(scaled_pixmap)