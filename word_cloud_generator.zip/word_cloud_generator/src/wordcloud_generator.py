import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from pathlib import Path

class WordCloudGenerator:
    def __init__(self):
        self.stop_words = {
            '的', '了', '和', '是', '就', '都', '而', '及', '与', '这', '那', '但',
            '在', '中', '为', '对', '等', '能', '到', '上', '种', '将', '已', '于',
            '向', '从', '或', '把', '被', '让', '给', '由', '着', '些', '很', '的话'
        }
        
        # 确保字体文件路径
        self.font_path = str(Path(__file__).parent.parent / 'static' / 'fonts' / 'SimHei.ttf')

    def generate(self, text, output_path='wordcloud.png', width=1000, height=600):
        """生成词云"""
        try:
            # 分词
            words = jieba.cut(text)
            word_space_split = ' '.join(words)
            
            # 创建词云对象
            wc = WordCloud(
                font_path=self.font_path,
                width=width,
                height=height,
                background_color='white',
                max_words=200,
                max_font_size=100,
                min_font_size=10,
                mode='RGBA',
                stopwords=self.stop_words,
                random_state=42
            )
            
            # 生成词云
            wc.generate(word_space_split)
            
            # 保存图片
            plt.figure(figsize=(12, 8), dpi=100)
            plt.imshow(wc, interpolation='bilinear')
            plt.axis('off')
            plt.savefig(output_path, bbox_inches='tight', pad_inches=0)
            plt.close()
            
            return True, "词云生成成功！"
            
        except Exception as e:
            return False, f"生成词云时出错：{str(e)}" 