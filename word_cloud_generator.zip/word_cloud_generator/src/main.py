import sys
from pathlib import Path
from PyQt5.QtWidgets import QApplication

# 添加项目根目录到 Python 路径
project_root = str(Path(__file__).parent.parent)
sys.path.insert(0, project_root)

from src.ui.main_window import MainWindow

def main():
    app = QApplication(sys.argv)
    
    # 设置应用样式
    style_path = Path(__file__).parent / 'ui' / 'resources' / 'style.qss'
    if style_path.exists():
        with open(style_path, 'r') as f:
            app.setStyleSheet(f.read())
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()