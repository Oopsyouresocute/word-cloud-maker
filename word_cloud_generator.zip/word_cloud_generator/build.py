import PyInstaller.__main__

PyInstaller.__main__.run([
    'src/main.py',
    '--name=词云生成器',
    '--windowed',
    '--add-data=static/fonts/SimHei.ttf;static/fonts',
    '--add-data=src/ui/resources/style.qss;ui/resources',
    '--noconfirm',
    '--clean'
]) 